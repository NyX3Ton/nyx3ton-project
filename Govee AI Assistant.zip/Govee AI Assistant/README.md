# Govee AI Agent Dashboard

A Gradio dashboard + local-LLM agent that can see and control your Govee
smart home devices.

## Roadmap

1. **Govee API client** (done) - `govee_client.py`, tested against your real account.
2. **Local LLM agent** (done) - CUDA -> OpenVINO -> CPU fallback, tool-calling
   over the Govee client, offline dispatch logic verified, semantic device/
   scene matching added.
3. **Gradio app** (done) - dashboard + chat panel wired to the agent.
4. Polish: state polling/refresh, error handling, packaging.

## Step 1 - Govee API client

Files:
- `govee_client.py` - `GoveeClient` wrapper around the Govee Open API
  (list devices, get state, send control commands, plus convenience
  helpers like `set_power` / `set_brightness` / `set_color_rgb` /
  `set_color_temp` / `set_scene`).
- `test_govee.py` - smoke test: lists your devices, their capabilities,
  and current state.

### Setup

```bash
cd govee_agent
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env
# edit .env and paste in your Govee API key
python test_govee.py
```

Get your API key from the **Govee Home App -> Profile -> Settings (gear
icon) -> Apply for API Key**. It's emailed to you, usually within a day.

### Corporate laptop note

If you hit an SSL verification error behind the TLS-inspection proxy
(same symptom as the weather app), either:
- set the `REQUESTS_CA_BUNDLE` env var to your corporate CA bundle, or
- pass `GoveeClient(verify="/path/to/corp-ca-bundle.pem")`.

### What to check before we move to Step 2

Run `test_govee.py` and confirm:
1. It lists all the devices you expect.
2. Each device's `capabilities` list looks right (power, brightness,
   color, colorTem, scenes - not every device supports every capability).
3. `state` returns sensible values for at least one device.

That capability list is what the LLM agent's tool schema will be built
from per-device in Step 2, so it's worth eyeballing now.

### API facts worth knowing

- Base host: `https://openapi.api.govee.com`
- Auth header: `Govee-API-Key: <key>`
- Rate limit: **10,000 requests/account/day** (HTTP 429 if exceeded) -
  the dashboard should poll state on an interval (e.g. every 30-60s),
  not on every Gradio re-render.
- Devices only report *device-reported* state for capabilities they
  support; unsupported instances just won't appear.

### Confirmed against your account

Your `test_govee.py` run found 9 devices: 6 lights (`Christmas Lights`,
`Bedroom Light`, `Bedroom Light 2`, `Table Lamp 1`, `Table Lamp 2`,
`LED Bulb String Lights`, `Bedroom Main Lamp` - some support scenes/music
mode/segments, some don't), a `Tower Fan` (power + oscillation + gear-mode
speed), and a `Wifi Thermometer` (read-only sensor). That mix is exactly
why the agent's tool schema is built dynamically per-device in Step 2.

## Step 2 - Local LLM agent with tool calling

Files:
- `agent.py` - `ModelBackend` (CUDA -> OpenVINO -> CPU loading, same pattern
  as `validator_llm.py`/`OpenVINOReasoner`), `GoveeTools` (LLM-callable
  functions wrapping `GoveeClient`, with fuzzy + semantic device-name
  matching and per-device capability checks), and `GoveeAgent` (the
  tool-call loop).
- `semantic_match.py` - embedding-based ("vector") fuzzy string matching,
  used as a fallback when exact/substring name matching can't resolve a
  device or scene name (paraphrases, typos, descriptions).
- `test_tools_offline.py` - exercises `GoveeTools` against your real
  devices/capabilities with no network or model needed. Covers the fan
  fix and semantic matching below.
- `agent_cli.py` - manual chat loop against the real model + real Govee
  account.

### Fan fix

`set_fan_speed` originally assumed the exact nested "Low/Medium/High"
schema shown in Govee's generic doc example - real fans often report
plain numbered gears (e.g. 1-8) with no names at all, which crashed with
an uncaught `KeyError`. It's now generic: it handles a flat `INTEGER`
range, a flat `ENUM` list, and a nested per-workMode `ENUM` list, with or
without names, mapping low/medium/high positionally when there are no
names to match against. `_call_tool` also now catches *any* exception
from a tool (not just the two expected types), so a bug in one tool
returns an error message to the model instead of crashing the whole turn.

### Semantic ("vector") matching

Exact/substring name matching still runs first (cheap, deterministic).
When that finds nothing, `_find_device` and `set_scene` fall back to
`semantic_match.best_match()`, which embeds the query and every candidate
name with a small local `sentence-transformers` model
(`all-MiniLM-L6-v2`, ~90MB, CPU) and picks the closest match - but only if
it clearly beats the runner-up; genuinely ambiguous cases (e.g. two
similarly-worded devices) still fall through to an error rather than
guessing. This lets things like "the lamp in the bedroom" or "the wifi
sensor" resolve without an exact name match, and lets scene requests like
"festive" have a shot at matching "Christmas". The offline tests exercise
this with an injected fake embedding model, so they run without
downloading anything.

### Model & tool-calling approach

- Model: `unsloth/Qwen3-4B-Instruct-2507` (same reasoner as the weather
  app). Qwen3's chat template supports Hermes-style tool calling directly -
  passing `tools=` to `apply_chat_template` makes the model emit
  `<tool_call>{"name": ..., "arguments": {...}}</tool_call>`, which
  `agent.py` parses and dispatches. No Qwen-Agent/MCP framework needed since
  we're calling one well-defined local tool surface, not external services.
- Tools exposed: `list_devices`, `get_device_state`, `set_power`,
  `set_brightness`, `set_color_rgb`, `set_color_temp`, `set_scene`,
  `set_toggle`, `set_fan_speed`. Each checks the specific device's real
  capabilities before calling the API and returns a clear error (with
  available options) if unsupported - e.g. asking to set scenes on the
  thermometer returns an error instead of crashing.

### Setup

```bash
pip install -r requirements-agent.txt
# if you have an NVIDIA GPU, install the matching CUDA torch build instead -
# see the comment at the top of requirements-agent.txt

# 1. logic-only test, no model/network required (already verified):
python test_tools_offline.py

# 2. full agent test with your real account + a real local model:
python agent_cli.py
```

`agent_cli.py`'s first run will download `Qwen3-4B-Instruct-2507` (~8GB),
export it to OpenVINO IR under `ov_cache/` if no CUDA GPU is found, and
download the ~90MB embedding model for semantic matching - a few minutes
total, one-time.

Retry the fan prompt that failed before, e.g. "set the tower fan to
medium", and let me know if it's resolving correctly now against your
actual gear schema.

## Step 3 - Gradio frontend

Files:
- `app.py` - `build_ui(client, agent)` builds a two-column dashboard:
  device cards on the left (status text + a power toggle and brightness
  slider for devices that support them, generated dynamically from your
  real device list) and a chat panel on the right wired to `GoveeAgent`.
  Manual dashboard controls and the chat agent operate on the same Govee
  account, so either one reflects in the other after a refresh.
- `test_app_build.py` - builds the same Gradio `Blocks` graph against a
  fake client and a stub agent (no model, no network, no server launch) -
  already run and passing, confirms the dynamic per-device wiring doesn't
  break before you point it at your real account.

### Setup

```bash
pip install -r requirements-app.txt
python app.py
```

This launches a local Gradio server (prints a `http://127.0.0.1:7860` URL
you can open in a browser). Startup loads the LLM agent first, so the
first run takes as long as `agent_cli.py`'s first run did.

### Notes

- State polling happens on page load, after a manual refresh click, and
  after each chat turn - not continuously - to stay well under the
  10,000 requests/day limit.
- The brightness slider only fires on release (not while dragging), same
  reasoning.
- `GRADIO_ANALYTICS_ENABLED` is disabled by default in `app.py` (relevant
  given the corporate proxy issues you've hit before with outbound calls).

### What to check

- Does the dashboard show all your devices with sensible status text?
- Does toggling power / dragging brightness from the dashboard work and
  reflect back correctly on refresh?
- Does chatting still work end-to-end, including the fan speed fix and
  semantic name matching?

Once that's solid, Step 4 is polish - background/async model loading so
the UI doesn't block on startup, periodic auto-refresh, nicer device
cards, and packaging.

